/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.wicket.commons.fileupload2;

import java.util.Iterator;

/**
 * This class provides support for accessing the headers for a file or form item that was received within a {@code multipart/form-data} POST request.
 *
 * @since 1.2.1
 */
public interface FileItemHeaders {

    /**
     * Gets the value of the specified part header as a {@code String}.
     * <p>
     * If the part did not include a header of the specified name, this method return {@code null}. If there are multiple headers with the same name, this
     * method returns the first header in the item. The header name is case insensitive.
     * </p>
     *
     * @param name a {@code String} specifying the header name
     * @return a {@code String} containing the value of the requested header, or {@code null} if the item does not have a header of that name
     */
    String getHeader(String name);

    /**
     * Gets an {@code Iterator} of all the header names.
     *
     * @return an {@code Iterator} containing all of the names of headers provided with this file item. If the item does not have any headers return an empty
     *         {@code Iterator}
     */
    Iterator<String> getHeaderNames();

    /**
     * Gets all the values of the specified item header as an {@code Iterator} of {@code String} objects.
     * <p>
     * If the item did not include any headers of the specified name, this method returns an empty {@code Iterator}. The header name is case insensitive.
     * </p>
     *
     * @param name a {@code String} specifying the header name
     * @return an {@code Iterator} containing the values of the requested header. If the item does not have any headers of that name, return an empty
     *         {@code Iterator}
     */
    Iterator<String> getHeaders(String name);

}
